package com.schibstedspain.leku.tracker

interface LocationPickerTracker {
    fun onEventTracked(event: TrackEvents)
}
