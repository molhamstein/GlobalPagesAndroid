package com.almersal.android.data.entitiesResponses

/**
 * Created by Adhamkh on 2018-09-14.
 */
class AttachmentResponse{
    var url: String=""
    constructor()

    constructor(url: String) {
        this.url = url
    }


}