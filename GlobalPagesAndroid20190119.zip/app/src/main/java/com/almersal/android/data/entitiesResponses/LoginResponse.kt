package com.almersal.android.data.entitiesResponses

import com.almersal.android.data.entities.User

/**
 * Created by Adhamkh on 2018-06-18.
 */
class LoginResponse {
    var id = ""
    var ttl = ""
    var created = ""
    var userId = ""
    var user: User = User()
}