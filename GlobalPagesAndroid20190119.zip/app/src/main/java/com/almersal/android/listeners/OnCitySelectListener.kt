package com.almersal.android.listeners

import com.almersal.android.data.entities.City

/**
 * Created by Adhamkh on 2018-07-26.
 */
interface OnCitySelectListener {
    fun onSelectCity(city: City)
}