package com.almersal.android.di.scope

import javax.inject.Qualifier

/**
 * Created by Adhamkh on 2017-12-18.
 */

@Qualifier
@Retention(AnnotationRetention.RUNTIME)
annotation class PerActivity
