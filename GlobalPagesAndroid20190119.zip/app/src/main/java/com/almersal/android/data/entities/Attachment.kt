package com.almersal.android.data.entities

/**
 * Created by Adhamkh on 2018-07-19.
 */
class Attachment {
    var name: String = ""
    var size: String = ""
    var atime: String = ""
    var mtime: String = ""
    var ctime: String = ""

    constructor()

    constructor(name: String) {
        this.name = name
    }


}