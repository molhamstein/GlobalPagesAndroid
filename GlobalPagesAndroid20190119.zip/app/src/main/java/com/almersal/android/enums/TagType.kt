package com.almersal.android.enums

/**
 * Created by Adhamkh on 2018-09-08.
 */
enum class TagType {
    Category, SubCategory, City, Location
}