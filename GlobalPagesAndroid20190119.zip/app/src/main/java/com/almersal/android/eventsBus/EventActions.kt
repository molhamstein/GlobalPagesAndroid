package com.almersal.android.eventsBus


class EventActions {
    companion object {
        const val LocationPickupActivity_Tag = "LocationPickupActivity_Tag"
        const val ProductAddActivity_Tag = "ProductAddActivity_Tag"
        const val SubCategorySubscriptionBottomSheet_Tag: String = "SubCategorySubscriptionBottomSheet_Tag"

//        const val BusinessGuideAddActivity_Tag = "BusinessGuideAddActivity_Tag"

    }
}