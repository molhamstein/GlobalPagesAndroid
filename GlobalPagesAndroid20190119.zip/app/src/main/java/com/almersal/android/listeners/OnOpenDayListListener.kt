package com.almersal.android.listeners

/**
 * Created by Adhamkh on 2018-10-12.
 */
interface OnOpenDayListListener {
    fun onOpenDayListSelect(openDayList: MutableList<String>)
}