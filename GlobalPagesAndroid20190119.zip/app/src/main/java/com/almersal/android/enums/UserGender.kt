package com.almersal.android.enums

/**
 * Created by Adhamkh on 2018-06-15.
 */
enum class UserGender(var gender: String) {
    male("male"), female("female")
}