package com.almersal.android.enums


enum class UserStatus(var status: String) {
    pending("pending"), active("activated")
}