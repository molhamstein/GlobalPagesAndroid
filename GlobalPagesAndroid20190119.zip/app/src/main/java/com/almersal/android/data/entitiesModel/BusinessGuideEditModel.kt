package com.almersal.android.data.entitiesModel

/**
 * Created by Adhamkh on 2018-10-15.
 */
class BusinessGuideEditModel : BusinessGuideModel() {
    var id: String? = null
}