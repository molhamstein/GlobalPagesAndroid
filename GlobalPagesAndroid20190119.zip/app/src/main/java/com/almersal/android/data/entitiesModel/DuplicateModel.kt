package com.almersal.android.data.entitiesModel

/**
 * Created by Adhamkh on 2018-06-30.
 */
class DuplicateModel(var duplicateEmail: Boolean, var duplicateUserName: Boolean)