package com.almersal.android.data.entitiesModel

/**
 * Created by Adhamkh on 2018-06-18.
 */
class ForgotPasswordModel {
    var email: String = ""
}