package com.almersal.android.data.entitiesModel

/**
 * Created by Adhamkh on 2018-06-15.
 */
class LoginModel {
    var email: String = ""
    var password: String = ""
}