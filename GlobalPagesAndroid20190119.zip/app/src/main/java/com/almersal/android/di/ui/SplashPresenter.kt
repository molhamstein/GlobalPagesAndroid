package com.almersal.android.di.ui

/**
 * Created by Adhamkh on 2018-08-09.
 */
class SplashPresenter {
}