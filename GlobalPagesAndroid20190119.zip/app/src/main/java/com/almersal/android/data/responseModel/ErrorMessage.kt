package com.almersal.android.data.responseModel

/**
 * Created by Adhamkh on 2018-06-15.
 */
class ErrorMessage {
    var statusCode: Int = 0
    var name: String = ""
    var message: String = ""
    var code: String = ""
    var stack: String = ""
}