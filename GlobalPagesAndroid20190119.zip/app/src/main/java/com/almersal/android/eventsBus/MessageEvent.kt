package com.almersal.android.eventsBus

/**
 * Created by Adhamkh on 2018-10-08.
 */
data class MessageEvent(val action: String,
                        val message: Any?)