package com.brainsocket.mainlibrary.Enums;

/**
 * Created by windows 8.1 on 2017-03-21.
 */

public enum LayoutStatesEnum {
    Noconnectionlayout, Nodatalayout, Waitinglayout, SuccessLayout, NopermissionLayout;
}
