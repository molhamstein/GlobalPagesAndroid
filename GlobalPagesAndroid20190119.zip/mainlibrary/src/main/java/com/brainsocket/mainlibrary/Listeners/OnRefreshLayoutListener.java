package com.brainsocket.mainlibrary.Listeners;

/**
 * Created by windows 8.1 on 2017-03-23.
 */

public interface OnRefreshLayoutListener {
    void onRefresh();

    void onRequestPermission();
}
